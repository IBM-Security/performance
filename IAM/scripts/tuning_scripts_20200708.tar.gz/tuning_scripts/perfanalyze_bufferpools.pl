#!/usr/bin/perl

# perfanalyze_bufferpools.pl

print STDERR <<EOL

The functionality of perfanalyze_bufferpools.pl is now available from
perfanalyze_database.pl. Use that script instead.

EOL
;
