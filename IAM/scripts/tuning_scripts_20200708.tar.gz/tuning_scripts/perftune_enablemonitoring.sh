#!/bin/sh
db2 update database manager configuration using DFT_MON_STMT ON
db2 update database manager configuration using DFT_MON_BUFPOOL ON
db2 update database manager configuration using DFT_MON_LOCK ON
db2 update database manager configuration using DFT_MON_SORT ON
db2 update database manager configuration using DFT_MON_TIMESTAMP ON
db2 update database manager configuration using DFT_MON_UOW ON
